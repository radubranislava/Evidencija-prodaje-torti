﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

// dodatno ukljuceno
using System.Data;
using DBUtils;
using System.Data.SqlClient;
using System.Globalization;

namespace KlasePodataka
{
    public class TortaDBClass : TabelaClass

    /* CRC karta - Class Responsibility Collaboration:  */
    //-----------------------------------------------------
    /* ODGOVORNOST: realizacija CRUD operacija nad tabelom Zvanje u bazi podataka */
    /* ZAVISNOST U ODNOSU NA DRUGE KLASE:
     Standardna klasa iz System.Data - DataSet
     Sopstvena klasa iz DBUtils - TabelaClass (bazna klasa)
     */
    {
        #region ATRIBUTI
        // imamo protected atribut Konekcija iz bazne klase
        // imamo sve iz bazne klase tabela
        #endregion

        // ne postavljamo property, jer postoji rizik da ostane prazan string konekcije, a bez njega ne moze
        // zato obavezujemo da se vrednost obezbedi kroz konstruktor

        #region KONSTRUKTOR

        public TortaDBClass() : base()
        {
            // ovo je obavezan dodatak, jer u baznom konstruktoru bez parametara se ostvaruje konekcija
            this.NazivTabele = "Torta";
        }

        public TortaDBClass(string nazivTabeleParametar) : base(nazivTabeleParametar)
        // izvrsava se konstruktor bazne klase, znaci istovremeno se instancira sve kao za objekat klase TabelaClass
        // ovde se u okviru ovakvog konstruktora bazne klase instancira objekat za konekciju i mi sada raspolazemo sa time
        // sada raspolazemo sa time i pisemo this.NAZIVI METODA ILI ATRIBUTA OD TE KLASE TabelaClass
        {
            // OVDE PISEMO KOD KOJI SE IZVRSAVA NAKON OSNOVNOG IZVRSAVANJA KONSTRUKTORA BAZNE KLASE           
        }

        public TortaDBClass(KonekcijaClass konekcijaParametar, string nazivTabeleParametar) : base(konekcijaParametar, nazivTabeleParametar)
        // izvrsava se konstruktor bazne klase, znaci istovremeno se instancira sve kao za objekat klase TabelaClass
        // _tabelaObject = new TabelaClass(_konekcijaObject, "Zvanje");
        // sada raspolazemo sa time i pisemo this.NAZIVI METODA ILI ATRIBUTA OD TE KLASE TabelaClass
        {
            // OVDE PISEMO KOD KOJI SE IZVRSAVA NAKON OSNOVNOG IZVRSAVANJA KONSTRUKTORA BAZNE KLASE           
        }

        #endregion
        // privatne metode

        #region JAVNE METODE
        public DataSet DajSveTorte()
        {
            DataSet podaciDataSet = new DataSet();
            string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\SQLEXPRESS; Initial Catalog=Tortee; Integrated Security=True;";
            using (SqlConnection konekcija = new SqlConnection(stringKonekcije)) 
            {
                string upit = "Select * from Torta";

                using (SqlDataAdapter adapter = new SqlDataAdapter(upit, konekcija))
                {
                    adapter.Fill(podaciDataSet);
                }
            } 

            return podaciDataSet;
        }

        public TortaClass DajTortuPremaSifri(string sifraTorteParametar)
        {
            TortaClass torta = null;
        
            string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\SQLEXPRESS; Initial Catalog=Tortee; Integrated Security=True;";
            using (SqlConnection konekcija = new SqlConnection(stringKonekcije))
            {
                try
                {
                    konekcija.Open();

                    string upit = "SELECT * FROM Torta WHERE Sifra = @Sifra";
                    SqlCommand komanda = new SqlCommand(upit, konekcija);
                    komanda.Parameters.AddWithValue("@Sifra", sifraTorteParametar);

                    using (SqlDataReader reader = komanda.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            
                            torta = new TortaClass();
                            torta.Sifra = reader["Sifra"].ToString();
                            torta.Naziv = reader["Naziv"].ToString();
                            torta.Ukus = reader["Ukus"].ToString();
                            torta.OblikTorte = reader["OblikTorte"].ToString();
                            torta.Cena = reader["Cena"].ToString();
                            string datumIzBaze = reader["DatumProdaje"].ToString();
                            DateTime datum = DateTime.ParseExact(datumIzBaze, "dd/MM/yyyy", CultureInfo.InvariantCulture);
                            torta.DatumProdaje = datum;
                            torta.Kolicina = reader["Kolicina"].ToString();



                          
                        }
                    }
                }
                catch (Exception ex)
                {
                    
                }
                finally
                {
                    konekcija.Close();
                }
            }

            return torta;
        }


        public decimal NajvecaZarada()
        {
            decimal najvecaZarada = 0;
            string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\SQLEXPRESS; Initial Catalog=Tortee; Integrated Security=True;";

            using (SqlConnection konekcija = new SqlConnection(stringKonekcije))
            {
                try
                {
                    konekcija.Open();
                    string upit = "SELECT TOP 1 Cena AS NajvecaZarada FROM Torta";
                    SqlCommand komanda = new SqlCommand(upit, konekcija);

                    object rezultat = komanda.ExecuteScalar();

                    if (rezultat != null && rezultat != DBNull.Value)
                    {
                        najvecaZarada = Convert.ToDecimal(rezultat);
                    }
                }
                catch (Exception ex)
                {
                    
                }
                finally
                {
                    konekcija.Close();
                }
            }

            return najvecaZarada;
        }


       



    

        public bool SnimiNovuTortu(TortaClass novaTortaObjectParametar)
        {
            bool uspeh = false;

            string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\SQLEXPRESS; Initial Catalog=Tortee; Integrated Security=True;";

            using (SqlConnection konekcija = new SqlConnection(stringKonekcije))
            {
                string upit= "INSERT INTO Torta(Sifra, Naziv, OblikTorte, Ukus, Kolicina, Cena, DatumProdaje) " +
                               "VALUES (@Sifra, @Naziv, @OblikTorte, @Ukus, @Kolicina, @Cena, @DatumProdaje)";

                using (SqlCommand komanda = new SqlCommand(upit, konekcija))
                {
                    komanda.Parameters.AddWithValue("@Sifra", novaTortaObjectParametar.Sifra);
                    komanda.Parameters.AddWithValue("@Naziv", novaTortaObjectParametar.Naziv);
                    komanda.Parameters.AddWithValue("@OblikTorte", novaTortaObjectParametar.OblikTorte); 
                    komanda.Parameters.AddWithValue("@Ukus", novaTortaObjectParametar.Ukus);
                    komanda.Parameters.AddWithValue("@Kolicina", novaTortaObjectParametar.Kolicina);
                    komanda.Parameters.AddWithValue("@Cena", novaTortaObjectParametar.Cena);
                    komanda.Parameters.AddWithValue("@DatumProdaje", novaTortaObjectParametar.DatumProdaje);

                    konekcija.Open();

                    int rowsAffected = komanda.ExecuteNonQuery();
                    uspeh = rowsAffected > 0;
                } 

            } 

            return uspeh;
        }

        public bool ObrisiTortu(TortaClass tortaZaBrisanjeObjectParametar)
        {
            bool uspeh = false;
            string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\SQLEXPRESS; Initial Catalog=Tortee; Integrated Security=True;";
            
            string upit = "DELETE FROM Torta WHERE Sifra=@Sifra";


            using (SqlConnection konekcija = new SqlConnection(stringKonekcije))
            {
                using (SqlCommand komanda = new SqlCommand(upit, konekcija))
                {
                   
                    komanda.Parameters.AddWithValue("@Sifra", tortaZaBrisanjeObjectParametar.Sifra);

                    try
                    {
                        konekcija.Open();
                        int brojRedova = komanda.ExecuteNonQuery();
                        uspeh = brojRedova > 0;
                    }
                    catch (Exception ex)
                    {
                        
                        uspeh = false;
                        
                    }
                } 
            }

            return uspeh;
        }

        public bool IzmeniTortu(TortaClass staraTorta, TortaClass novaTorta)
        {
            bool uspeh = false;

            string upit = "UPDATE Torta SET Naziv=@NoviNaziv, OblikTorte=@NoviOblikTorte, Ukus=@NoviUkus, Kolicina=@NovaKolicina, Cena=@NovaCena, DatumProdaje=@NoviDatumProdaje WHERE Sifra=@StaraSifra";
            string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\SQLEXPRESS; Initial Catalog=Tortee; Integrated Security=True;";
        
            using (SqlConnection konekcija = new SqlConnection(stringKonekcije))
            {
                konekcija.Open();

                using (SqlCommand komanda = new SqlCommand(upit, konekcija))
                {
                    komanda.Parameters.AddWithValue("@NoviNaziv", novaTorta.Naziv);
                    komanda.Parameters.AddWithValue("@NoviOblikTorte", novaTorta.OblikTorte);
                    komanda.Parameters.AddWithValue("@NoviUkus", novaTorta.Ukus);
                    komanda.Parameters.AddWithValue("@NovaKolicina", novaTorta.Kolicina);
                    komanda.Parameters.AddWithValue("@NovaCena", novaTorta.Cena);
                    komanda.Parameters.AddWithValue("@NoviDatumProdaje", novaTorta.DatumProdaje);
                    komanda.Parameters.AddWithValue("@StaraSifra", staraTorta.Sifra);
                    komanda.Parameters.AddWithValue("@datum", DateTime.Parse("2023-09-20"));
                    int brojAžuriranihRedova = komanda.ExecuteNonQuery();

                    if (brojAžuriranihRedova > 0)
                    {
                        uspeh = true;
                    }
                    else
                    {
                        uspeh = false;
                    }
                }
            }

            return uspeh;
        }
    }
    #endregion
}

