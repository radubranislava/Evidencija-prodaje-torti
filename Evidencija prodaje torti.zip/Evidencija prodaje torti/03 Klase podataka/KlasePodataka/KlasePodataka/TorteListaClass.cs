﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class TorteListaClass
    /* CRC karta - Class Responsibility Collaboration:  */
    //-----------------------------------------------------
    /* ODGOVORNOST: Klasa tipa liste koja sadrzi kao elemente objekte klase tipa pojedinac ZvanjeClass */
    /* ZAVISNOST U ODNOSU NA DRUGE KLASE:
     Standardna klasa iz System.Collections.Generic - List
     Sopstvena klasa iz ove biblioteke - ZvanjeClass
     */
    {
        #region ATRIBUTI
        private List<TortaClass> _listaTorti;
        #endregion

        #region PROPERTY
        // property
        public List<TortaClass> ListaTorti
        {
            get
            {
                return _listaTorti;
            }
            set
            {
                if (this._listaTorti != value)
                    this._listaTorti = value;
            }
        }
        #endregion

        #region KONSTRUKTOR
        public TorteListaClass()
        {
            _listaTorti = new List<TortaClass>();

        }
        #endregion


        // privatne metode

        #region JAVNE METODE
        public void DodajElementListe(TortaClass NovaTortaParametar)
        {
            _listaTorti.Add(NovaTortaParametar);
        }

        public void ObrisiElementListe(TortaClass TortaZaBrisanjeParametar)
        {
            _listaTorti.Remove(TortaZaBrisanjeParametar);
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            _listaTorti.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(TortaClass objStaraTortaParametar, TortaClass NovaTortaParametar)
        {
            int indexStarihTorti = 0;
            indexStarihTorti = _listaTorti.IndexOf(objStaraTortaParametar);
            _listaTorti.RemoveAt(indexStarihTorti);
            _listaTorti.Insert(indexStarihTorti, NovaTortaParametar);
        }

        #endregion

    }
}
