﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace KlasePodataka
{
    public class TortaClass
    // NAMENA: 
    /* CRC karta - Class Responsibility Collaboration:  */
    //-----------------------------------------------------
    /* ODGOVORNOST: Klasa tipa pojedinac (ima samo atribute i property) za rad sa zvanjem */
    /* ZAVISNOST U ODNOSU NA DRUGE KLASE: nema
     */
    {
        #region ATRIBUTI
        private string _sifra;
        private string _naziv;
        private string _cena;
        private DateTime _datumprodaje;
        private string _obliktorte;
        private string _ukus;
        private string _kolicina;


        #endregion

        #region PROPERTY
        // property
        public string Sifra
        {
            get
            {
                return _sifra;
            }
            set
            {
                if (this._sifra != value)
                    this._sifra = value;
            }
        }

        public string Ukus
        {
            get
            {
                return _ukus;
            }
            set
            {
                if (this._ukus != value)
                    this._ukus = value;
            }
        }
        public string OblikTorte
        {
            get
            {
                return _obliktorte;
            }
            set
            {
                if (this._obliktorte != value)
                    this._obliktorte = value;
            }
        }
        public string Kolicina
        {
            get
            {
                return _kolicina;
            }
            set
            {
                if (this._kolicina != value)
                    this._kolicina = value;
            }
        }
        public string Naziv
        {
            get
            {
                return _naziv;
            }
            set
            {
                if (this._naziv != value)
                    this._naziv = value;
            }
        }
        public DateTime DatumProdaje
        {
            get
            {
                return _datumprodaje;
            }
            set
            {
                if (this._datumprodaje != value)
                    this._datumprodaje = value;
            }
        }
        public string Cena
        {
            get
            {
                return _cena;
            }
            set
            {
                if (this._cena != value)
                    this._cena = value;
            }
        }
        #endregion

        #region KONSTRUKTOR
        // konstruktor
        public TortaClass()
        {
            _sifra = "";
            _naziv = "";
            _kolicina = "";
            _obliktorte = "";
            _ukus = "";
            _cena = "";
            _datumprodaje = DateTime.Now;

        }

        #endregion

        // privatne metode

        // javne metode
    }
}
