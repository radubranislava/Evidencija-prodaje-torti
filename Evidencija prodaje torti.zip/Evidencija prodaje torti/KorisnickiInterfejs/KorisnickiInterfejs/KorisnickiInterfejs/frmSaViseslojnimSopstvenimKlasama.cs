﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
//
using KlasePodataka;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;


namespace KorisnickiInterfejs
{
    public partial class frmSaViseslojnimSopstvenimKlasama : Form
    {
        // ------------ ATRIBUTI
        // #################################################
        private DataTable podaciDataTable;
        private DataSet podaciDataSet;
        private TortaDBClass TortaDBObject;

        // ------------ METODE
        // #################################################

        // -----------------NASE PROCEDURE
        private void IsprazniKontrole()
        {
            OznakaTextBox.Text = "";
            NazivTextBox.Text = "";
            KolicinaTextBox.Text = "";
            OblikTorteTextBox.Text = "";
            DatumProdaje.Text = "";
            CenaTextBox.Text = "";
            UkusTextBox.Text = "";
            BrisanjeOznakaTextBox.Text= "";

        }

        private void AktivirajKontrole()
        {
            OznakaTextBox.Enabled = true;
            NazivTextBox.Enabled = true;

            KolicinaTextBox.Enabled = true;
            UkusTextBox.Enabled = true;

            CenaTextBox.Enabled = true;
            DatumProdaje.Enabled = true;

            BrisanjeOznakaTextBox.Enabled = true;
            OblikTorteTextBox.Enabled = true;

        }

        private void DeaktivirajKontrole()
        {
            OznakaTextBox.Enabled = false;
            NazivTextBox.Enabled = false;
            DatumProdaje.Enabled = false;
            OblikTorteTextBox.Enabled = false;
            CenaTextBox.Enabled = false;
            UkusTextBox.Enabled = false;
            KolicinaTextBox.Enabled = false;
            OblikTorteTextBox.Enabled = false;

        }


        private void PrikaziTabeluPodataka(DataTable podaciDataTable)
        {
            SpisakTortiDataGridView.DataSource = podaciDataTable;
            SpisakTortiDataGridView.Refresh();
        }

        private void PrikaziTabeluPodataka(DataSet podaciDataSet)
        {
            SpisakTortiDataGridView.DataSource = podaciDataSet.Tables[0];
            SpisakTortiDataGridView.Refresh();
        }

        private void SnimiXML(DataTable podaci, string putanja)
        {
            DataSet dsPodaciEksport = new DataSet();

            // s obzirom da smo dobili kroz parametar poziva ove procedure "podaci"
            // zapravo samo promenljivu koja sadrzi memorijsku lokaciju, pokazivac 
            // ka podacima, javlja se problem kada ovaj isti DataTable "podaci"
            // vezemo sa drugim datasetom "dsPodaciExport" jer je taj DataTable
            // vec povezan sa dsPodaci u okviru procedure UcitajSve i UcitajTabelarno.
            // Zato moramo da radimo Copy, da kopiramo strukturu i podatke u NOVI DataTable.
            DataTable podaciZaEksport = new DataTable();
            podaciZaEksport = podaci.Copy();
            dsPodaciEksport.Tables.Add(podaciZaEksport);
            dsPodaciEksport.WriteXml(putanja);
        }


        // KONSTRUKTOR
        public frmSaViseslojnimSopstvenimKlasama()
        {
            InitializeComponent();
        }

        // DOGADJAJI
        private void frmSaViseslojnimSopstvenimKlasama_Load(object sender, EventArgs e)
        {
            podaciDataSet = new DataSet();
            podaciDataTable = new DataTable();
            TortaDBObject = new TortaDBClass();

        }

        private void btnUnos_Click(object sender, EventArgs e)
        {
            IsprazniKontrole();
            AktivirajKontrole();
            OznakaTextBox.Focus();
        }

        private void btnSnimi_Click(object sender, EventArgs e)
        {
            string poruka = "";


            TortaClass ObjekatTorte = new TortaClass();
            ObjekatTorte.Sifra = OznakaTextBox.Text;
            ObjekatTorte.Naziv = NazivTextBox.Text;
            ObjekatTorte.Kolicina = KolicinaTextBox.Text;
            ObjekatTorte.DatumProdaje = DatumProdaje.Value;

            ObjekatTorte.OblikTorte = OblikTorteTextBox.Text;
            ObjekatTorte.Ukus = UkusTextBox.Text;
            ObjekatTorte.Cena = CenaTextBox.Text;



            bool uspesnoSnimljeno = TortaDBObject.SnimiNovuTortu(ObjekatTorte);
            if (uspesnoSnimljeno)
            {
                poruka = "Uspesno snimljeno!";
            }
            else
            {
                poruka = "Nije uspesno snimljeno!";
            }
            DeaktivirajKontrole();
            MessageBox.Show(poruka);
        }

        private void btnOdustani_Click(object sender, EventArgs e)
        {
            IsprazniKontrole();
            DeaktivirajKontrole();
        }


        private void btnSve_Click(object sender, EventArgs e)
        {
            podaciDataSet = TortaDBObject.DajSveTorte();
            PrikaziTabeluPodataka(podaciDataSet);
        }

        private void btnExportXML_Click(object sender, EventArgs e)
        {
            SnimiXML(podaciDataSet.Tables[0], Parametri.putanjaXML);
            MessageBox.Show("Uspesno realizovan eksport podataka!");
        }

     

        private void BrisanjeButton_Click(object sender, EventArgs e)
        {
           
            string sifraTorte = BrisanjeOznakaTextBox.Text;

            if (string.IsNullOrEmpty(sifraTorte))
            {
                MessageBox.Show("Unesite ispravnu šifru torte za brisanje.");
                return;
            }

            
            DialogResult poruka = MessageBox.Show("Da li ste sigurni da želite da obrišete ovu tortu?", "Potvrda brisanja", MessageBoxButtons.YesNo);

            if (poruka == DialogResult.Yes)
            {
                TortaClass tortaZaBrisanje = new TortaClass
                {
                    Sifra = sifraTorte
                };

                bool uspesnoBrisanje = TortaDBObject.ObrisiTortu(tortaZaBrisanje);

                if (uspesnoBrisanje)
                {
                    MessageBox.Show("Torta je uspešno obrisana!");
                    IsprazniKontrole();
                }
                else
                {
                    MessageBox.Show("Nije uspelo brisanje torte.");
                }
            }
            else
            {
                
                MessageBox.Show("Brisanje je otkazano.");
            }
        }






        private void NajvecaZaradaButton_Click(object sender, EventArgs e)
        {
            decimal najvecaZarada = TortaDBObject.NajvecaZarada();

            
            NajvecaZaradaTextBox.Text = najvecaZarada.ToString();
        }

        private void FiltrirajButton_Click(object sender, EventArgs e)
        {
            string sifraTorte = FilterTextBox.Text;
            TortaClass torta = TortaDBObject.DajTortuPremaSifri(sifraTorte);

            if (torta != null)
            {
               
                DataTable tabela = new DataTable("Torta");
                tabela.Columns.Add("Sifra");
                tabela.Columns.Add("Naziv");
                tabela.Columns.Add("OblikTorte");
                tabela.Columns.Add("Ukus");
                tabela.Columns.Add("Kolicina");
                tabela.Columns.Add("Cena");
                tabela.Columns.Add("DatumProdaje");

                tabela.Rows.Add(torta.Sifra, torta.Naziv, torta.OblikTorte, torta.Ukus, torta.Kolicina, torta.Cena, torta.DatumProdaje);

                DataSet noviDataSet = new DataSet();
                noviDataSet.Tables.Add(tabela);

                PrikaziTabeluPodataka(noviDataSet);
            }
            else
            {
                MessageBox.Show("Torta sa unetom šifrom nije pronađena.");
            }

        }

    



        private void SpisakTortiDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
              
                DataGridViewRow row = this.SpisakTortiDataGridView.Rows[e.RowIndex];
              
                OznakaTextBox.Text = row.Cells[0].Value.ToString();
                NazivTextBox.Text = row.Cells[1].Value.ToString();
                OblikTorteTextBox.Text = row.Cells[2].Value.ToString();
                UkusTextBox.Text = row.Cells[3].Value.ToString();
                KolicinaTextBox.Text = row.Cells[4].Value.ToString();
                CenaTextBox.Text = row.Cells[5].Value.ToString();
                DatumProdaje.Text = row.Cells[6].Value.ToString();
            }
        }

        private void IzmenaButton_Click(object sender, EventArgs e)
        {

            string poruka = "";

            
            TortaClass staraTorta = new TortaClass
            {
                Sifra = OznakaTextBox.Text 
            };

            TortaClass novaTorta = new TortaClass
            {
                Sifra = OznakaTextBox.Text, 
                Ukus = UkusTextBox.Text,
                Kolicina = KolicinaTextBox.Text,
                OblikTorte = OblikTorteTextBox.Text,
                DatumProdaje =  DatumProdaje.Value,
            Naziv = NazivTextBox.Text,
                Cena = CenaTextBox.Text
            };

            
            bool uspesnoIzmenjeno = TortaDBObject.IzmeniTortu(staraTorta, novaTorta);

            if (uspesnoIzmenjeno)
            {
                poruka = "Uspesno izmenjeno!";
            }
            else
            {
                poruka = "Nije uspesno izmenjeno!";
            }
          DeaktivirajKontrole();
            MessageBox.Show(poruka);
        }

        private void BrisanjeOznakaTextBox_TextChanged(object sender, EventArgs e)
        {

        }
    }

}

