﻿namespace KorisnickiInterfejs
{
    partial class frmSaViseslojnimSopstvenimKlasama
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSaViseslojnimSopstvenimKlasama));
            this.FilterTextBox = new System.Windows.Forms.TextBox();
            this.SveButton = new System.Windows.Forms.Button();
            this.ExportXMLButton = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.FiltrirajButton = new System.Windows.Forms.Button();
            this.IzmenaButton = new System.Windows.Forms.Button();
            this.OdustaniButton = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.NajvecaZaradaTextBox = new System.Windows.Forms.TextBox();
            this.NajvecaZaradaButton = new System.Windows.Forms.Button();
            this.SpisakTortiDataGridView = new System.Windows.Forms.DataGridView();
            this.BrisanjeButton = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.BrisanjeOznakaTextBox = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.OblikTorteTextBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.CenaTextBox = new System.Windows.Forms.TextBox();
            this.UkusTextBox = new System.Windows.Forms.TextBox();
            this.KolicinaTextBox = new System.Windows.Forms.TextBox();
            this.SnimiButton = new System.Windows.Forms.Button();
            this.UnosButton = new System.Windows.Forms.Button();
            this.NazivTextBox = new System.Windows.Forms.TextBox();
            this.OznakaTextBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.DatumProdaje = new System.Windows.Forms.DateTimePicker();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SpisakTortiDataGridView)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // FilterTextBox
            // 
            this.FilterTextBox.Location = new System.Drawing.Point(102, 319);
            this.FilterTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.FilterTextBox.Name = "FilterTextBox";
            this.FilterTextBox.Size = new System.Drawing.Size(136, 28);
            this.FilterTextBox.TabIndex = 13;
            // 
            // SveButton
            // 
            this.SveButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.SveButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SveButton.Location = new System.Drawing.Point(368, 473);
            this.SveButton.Margin = new System.Windows.Forms.Padding(4);
            this.SveButton.Name = "SveButton";
            this.SveButton.Size = new System.Drawing.Size(91, 34);
            this.SveButton.TabIndex = 11;
            this.SveButton.Text = "SVE";
            this.SveButton.UseVisualStyleBackColor = false;
            this.SveButton.Click += new System.EventHandler(this.btnSve_Click);
            // 
            // ExportXMLButton
            // 
            this.ExportXMLButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ExportXMLButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ExportXMLButton.Location = new System.Drawing.Point(467, 473);
            this.ExportXMLButton.Margin = new System.Windows.Forms.Padding(4);
            this.ExportXMLButton.Name = "ExportXMLButton";
            this.ExportXMLButton.Size = new System.Drawing.Size(186, 33);
            this.ExportXMLButton.TabIndex = 14;
            this.ExportXMLButton.Text = "EXPORT XML";
            this.ExportXMLButton.UseVisualStyleBackColor = false;
            this.ExportXMLButton.Click += new System.EventHandler(this.btnExportXML_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label3.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(17, 321);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(77, 25);
            this.label3.TabIndex = 12;
            this.label3.Text = "Naziv:";
            // 
            // FiltrirajButton
            // 
            this.FiltrirajButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.FiltrirajButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FiltrirajButton.Location = new System.Drawing.Point(266, 318);
            this.FiltrirajButton.Margin = new System.Windows.Forms.Padding(4);
            this.FiltrirajButton.Name = "FiltrirajButton";
            this.FiltrirajButton.Size = new System.Drawing.Size(148, 34);
            this.FiltrirajButton.TabIndex = 10;
            this.FiltrirajButton.Text = "FILTRIRAJ";
            this.FiltrirajButton.UseVisualStyleBackColor = false;
            this.FiltrirajButton.Click += new System.EventHandler(this.FiltrirajButton_Click);
            // 
            // IzmenaButton
            // 
            this.IzmenaButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.IzmenaButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IzmenaButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.IzmenaButton.Location = new System.Drawing.Point(512, 480);
            this.IzmenaButton.Margin = new System.Windows.Forms.Padding(4);
            this.IzmenaButton.Name = "IzmenaButton";
            this.IzmenaButton.Size = new System.Drawing.Size(118, 39);
            this.IzmenaButton.TabIndex = 15;
            this.IzmenaButton.Text = "IZMENA";
            this.IzmenaButton.UseVisualStyleBackColor = false;
            this.IzmenaButton.Click += new System.EventHandler(this.IzmenaButton_Click);
            // 
            // OdustaniButton
            // 
            this.OdustaniButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.OdustaniButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OdustaniButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.OdustaniButton.Location = new System.Drawing.Point(690, 479);
            this.OdustaniButton.Margin = new System.Windows.Forms.Padding(4);
            this.OdustaniButton.Name = "OdustaniButton";
            this.OdustaniButton.Size = new System.Drawing.Size(150, 38);
            this.OdustaniButton.TabIndex = 13;
            this.OdustaniButton.Text = "ODUSTANI";
            this.OdustaniButton.UseVisualStyleBackColor = false;
            this.OdustaniButton.Click += new System.EventHandler(this.btnOdustani_Click);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.NajvecaZaradaTextBox);
            this.groupBox2.Controls.Add(this.NajvecaZaradaButton);
            this.groupBox2.Controls.Add(this.ExportXMLButton);
            this.groupBox2.Controls.Add(this.FilterTextBox);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.SveButton);
            this.groupBox2.Controls.Add(this.FiltrirajButton);
            this.groupBox2.Controls.Add(this.SpisakTortiDataGridView);
            this.groupBox2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(844, 13);
            this.groupBox2.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox2.Size = new System.Drawing.Size(834, 525);
            this.groupBox2.TabIndex = 11;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "PRIKAZ PRODATIH TORTI";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label12.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(3, 396);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(176, 25);
            this.label12.TabIndex = 17;
            this.label12.Text = "Najveća zarada:";
            // 
            // NajvecaZaradaTextBox
            // 
            this.NajvecaZaradaTextBox.Location = new System.Drawing.Point(201, 396);
            this.NajvecaZaradaTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.NajvecaZaradaTextBox.Name = "NajvecaZaradaTextBox";
            this.NajvecaZaradaTextBox.Size = new System.Drawing.Size(171, 28);
            this.NajvecaZaradaTextBox.TabIndex = 16;
            // 
            // NajvecaZaradaButton
            // 
            this.NajvecaZaradaButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.NajvecaZaradaButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NajvecaZaradaButton.Location = new System.Drawing.Point(380, 392);
            this.NajvecaZaradaButton.Margin = new System.Windows.Forms.Padding(4);
            this.NajvecaZaradaButton.Name = "NajvecaZaradaButton";
            this.NajvecaZaradaButton.Size = new System.Drawing.Size(273, 34);
            this.NajvecaZaradaButton.TabIndex = 15;
            this.NajvecaZaradaButton.Text = "NAJVEĆA ZARADA";
            this.NajvecaZaradaButton.UseVisualStyleBackColor = false;
            this.NajvecaZaradaButton.Click += new System.EventHandler(this.NajvecaZaradaButton_Click);
            // 
            // SpisakTortiDataGridView
            // 
            this.SpisakTortiDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveCaption;
            this.SpisakTortiDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.SpisakTortiDataGridView.GridColor = System.Drawing.SystemColors.MenuHighlight;
            this.SpisakTortiDataGridView.Location = new System.Drawing.Point(8, 38);
            this.SpisakTortiDataGridView.Margin = new System.Windows.Forms.Padding(4);
            this.SpisakTortiDataGridView.Name = "SpisakTortiDataGridView";
            this.SpisakTortiDataGridView.RowHeadersWidth = 51;
            this.SpisakTortiDataGridView.Size = new System.Drawing.Size(844, 212);
            this.SpisakTortiDataGridView.TabIndex = 9;
            this.SpisakTortiDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.SpisakTortiDataGridView_CellClick);
            // 
            // BrisanjeButton
            // 
            this.BrisanjeButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.BrisanjeButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BrisanjeButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BrisanjeButton.Location = new System.Drawing.Point(690, 413);
            this.BrisanjeButton.Margin = new System.Windows.Forms.Padding(4);
            this.BrisanjeButton.Name = "BrisanjeButton";
            this.BrisanjeButton.Size = new System.Drawing.Size(147, 38);
            this.BrisanjeButton.TabIndex = 14;
            this.BrisanjeButton.Text = "BRISANJE";
            this.BrisanjeButton.UseVisualStyleBackColor = false;
            this.BrisanjeButton.Click += new System.EventHandler(this.BrisanjeButton_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox1.BackgroundImage")));
            this.groupBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.groupBox1.Controls.Add(this.DatumProdaje);
            this.groupBox1.Controls.Add(this.dateTimePicker);
            this.groupBox1.Controls.Add(this.BrisanjeOznakaTextBox);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.OblikTorteTextBox);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.CenaTextBox);
            this.groupBox1.Controls.Add(this.UkusTextBox);
            this.groupBox1.Controls.Add(this.KolicinaTextBox);
            this.groupBox1.Controls.Add(this.IzmenaButton);
            this.groupBox1.Controls.Add(this.BrisanjeButton);
            this.groupBox1.Controls.Add(this.OdustaniButton);
            this.groupBox1.Controls.Add(this.SnimiButton);
            this.groupBox1.Controls.Add(this.UnosButton);
            this.groupBox1.Controls.Add(this.NazivTextBox);
            this.groupBox1.Controls.Add(this.OznakaTextBox);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.groupBox1.Location = new System.Drawing.Point(-4, 13);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(840, 525);
            this.groupBox1.TabIndex = 10;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "UNOS TORTE";
            // 
            // BrisanjeOznakaTextBox
            // 
            this.BrisanjeOznakaTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.BrisanjeOznakaTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BrisanjeOznakaTextBox.Location = new System.Drawing.Point(484, 418);
            this.BrisanjeOznakaTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.BrisanjeOznakaTextBox.Name = "BrisanjeOznakaTextBox";
            this.BrisanjeOznakaTextBox.Size = new System.Drawing.Size(168, 28);
            this.BrisanjeOznakaTextBox.TabIndex = 33;
            this.BrisanjeOznakaTextBox.TextChanged += new System.EventHandler(this.BrisanjeOznakaTextBox_TextChanged);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label13.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(8, 419);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(443, 25);
            this.label13.TabIndex = 18;
            this.label13.Text = "Unesite šifru torte koju želite da obrišete:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.Info;
            this.label11.Font = new System.Drawing.Font("Yu Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label11.Location = new System.Drawing.Point(14, 248);
            this.label11.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(327, 36);
            this.label11.TabIndex = 32;
            this.label11.Text = "Informacije o kupovini:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.SystemColors.Info;
            this.label10.Font = new System.Drawing.Font("Yu Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label10.Location = new System.Drawing.Point(14, 113);
            this.label10.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(270, 36);
            this.label10.TabIndex = 31;
            this.label10.Text = "Informacije o torti:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label9.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label9.Location = new System.Drawing.Point(507, 286);
            this.label9.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(173, 25);
            this.label9.TabIndex = 30;
            this.label9.Text = "Datum prodaje:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label8.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(213, 321);
            this.label8.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 25);
            this.label8.TabIndex = 29;
            this.label8.Text = "Cena:";
            // 
            // OblikTorteTextBox
            // 
            this.OblikTorteTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OblikTorteTextBox.Location = new System.Drawing.Point(439, 194);
            this.OblikTorteTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.OblikTorteTextBox.Name = "OblikTorteTextBox";
            this.OblikTorteTextBox.Size = new System.Drawing.Size(152, 28);
            this.OblikTorteTextBox.TabIndex = 22;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label7.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(19, 321);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(104, 25);
            this.label7.TabIndex = 28;
            this.label7.Text = "Količina:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label6.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(599, 194);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 25);
            this.label6.TabIndex = 27;
            this.label6.Text = "Ukus:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(299, 194);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 25);
            this.label5.TabIndex = 26;
            this.label5.Text = "Oblik torte:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(20, 177);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 27);
            this.label4.TabIndex = 25;
            // 
            // CenaTextBox
            // 
            this.CenaTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CenaTextBox.Location = new System.Drawing.Point(292, 319);
            this.CenaTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.CenaTextBox.Name = "CenaTextBox";
            this.CenaTextBox.Size = new System.Drawing.Size(101, 28);
            this.CenaTextBox.TabIndex = 23;
            // 
            // UkusTextBox
            // 
            this.UkusTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UkusTextBox.Location = new System.Drawing.Point(679, 197);
            this.UkusTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.UkusTextBox.Name = "UkusTextBox";
            this.UkusTextBox.Size = new System.Drawing.Size(150, 28);
            this.UkusTextBox.TabIndex = 21;
            // 
            // KolicinaTextBox
            // 
            this.KolicinaTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.KolicinaTextBox.Location = new System.Drawing.Point(131, 321);
            this.KolicinaTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.KolicinaTextBox.Name = "KolicinaTextBox";
            this.KolicinaTextBox.Size = new System.Drawing.Size(66, 28);
            this.KolicinaTextBox.TabIndex = 20;
            // 
            // SnimiButton
            // 
            this.SnimiButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.SnimiButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SnimiButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.SnimiButton.Location = new System.Drawing.Point(408, 481);
            this.SnimiButton.Margin = new System.Windows.Forms.Padding(4);
            this.SnimiButton.Name = "SnimiButton";
            this.SnimiButton.Size = new System.Drawing.Size(96, 36);
            this.SnimiButton.TabIndex = 12;
            this.SnimiButton.Text = "SNIMI";
            this.SnimiButton.UseVisualStyleBackColor = false;
            this.SnimiButton.Click += new System.EventHandler(this.btnSnimi_Click);
            // 
            // UnosButton
            // 
            this.UnosButton.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.UnosButton.Font = new System.Drawing.Font("Cooper Black", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UnosButton.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.UnosButton.Location = new System.Drawing.Point(304, 481);
            this.UnosButton.Margin = new System.Windows.Forms.Padding(4);
            this.UnosButton.Name = "UnosButton";
            this.UnosButton.Size = new System.Drawing.Size(96, 36);
            this.UnosButton.TabIndex = 11;
            this.UnosButton.Text = "UNOS";
            this.UnosButton.UseVisualStyleBackColor = false;
            this.UnosButton.Click += new System.EventHandler(this.btnUnos_Click);
            // 
            // NazivTextBox
            // 
            this.NazivTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NazivTextBox.Location = new System.Drawing.Point(105, 194);
            this.NazivTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.NazivTextBox.Name = "NazivTextBox";
            this.NazivTextBox.Size = new System.Drawing.Size(179, 28);
            this.NazivTextBox.TabIndex = 10;
            // 
            // OznakaTextBox
            // 
            this.OznakaTextBox.BackColor = System.Drawing.SystemColors.Window;
            this.OznakaTextBox.Font = new System.Drawing.Font("Arial Narrow", 10.8F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OznakaTextBox.Location = new System.Drawing.Point(105, 48);
            this.OznakaTextBox.Margin = new System.Windows.Forms.Padding(4);
            this.OznakaTextBox.Name = "OznakaTextBox";
            this.OznakaTextBox.Size = new System.Drawing.Size(179, 28);
            this.OznakaTextBox.TabIndex = 9;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label2.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(21, 194);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(77, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Naziv:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Century Schoolbook", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label1.Location = new System.Drawing.Point(20, 48);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(68, 25);
            this.label1.TabIndex = 7;
            this.label1.Text = "Šifra:";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(1332, 396);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 34);
            this.dateTimePicker.TabIndex = 35;
            // 
            // DatumProdaje
            // 
            this.DatumProdaje.Location = new System.Drawing.Point(413, 313);
            this.DatumProdaje.Name = "DatumProdaje";
            this.DatumProdaje.Size = new System.Drawing.Size(420, 34);
            this.DatumProdaje.TabIndex = 37;
            // 
            // frmSaViseslojnimSopstvenimKlasama
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1709, 551);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmSaViseslojnimSopstvenimKlasama";
            this.Text = "frmSaViseslojnimSopstvenimKlasama";
            this.Load += new System.EventHandler(this.frmSaViseslojnimSopstvenimKlasama_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.SpisakTortiDataGridView)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox FilterTextBox;
        private System.Windows.Forms.Button SveButton;
        private System.Windows.Forms.Button ExportXMLButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button FiltrirajButton;
        private System.Windows.Forms.Button IzmenaButton;
        private System.Windows.Forms.Button OdustaniButton;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView SpisakTortiDataGridView;
        private System.Windows.Forms.Button BrisanjeButton;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button SnimiButton;
        private System.Windows.Forms.Button UnosButton;
        private System.Windows.Forms.TextBox NazivTextBox;
        private System.Windows.Forms.TextBox OznakaTextBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox CenaTextBox;
        private System.Windows.Forms.TextBox OblikTorteTextBox;
        private System.Windows.Forms.TextBox UkusTextBox;
        private System.Windows.Forms.TextBox KolicinaTextBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button NajvecaZaradaButton;
        private System.Windows.Forms.TextBox NajvecaZaradaTextBox;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox BrisanjeOznakaTextBox;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.DateTimePicker DatumProdaje;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
    }
}