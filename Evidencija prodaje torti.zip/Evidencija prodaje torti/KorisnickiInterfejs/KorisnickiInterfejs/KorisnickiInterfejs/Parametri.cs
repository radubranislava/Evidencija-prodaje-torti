﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using System.Windows.Forms;

namespace KorisnickiInterfejs
{
    public static class Parametri
    {
        public static string stringKonekcije = "Data Source=DESKTOP-TRRT61G\\MSSQL2008; Initial Catalog=Tortee; Integrated Security=True;";
        public static string putanjaXML = Application.StartupPath + "\\eksport.XML";
       
    }
}
